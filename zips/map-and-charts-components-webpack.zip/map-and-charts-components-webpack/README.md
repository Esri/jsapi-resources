# Components (Map and Charts) Webpack sample

📁 **[Click here to download this directory as a ZIP file](https://esri.github.io/jsapi-resources/zips/map-and-charts-components-webpack.zip)** 📁

This sample demonstrates how to use the Map and Charts components from the ArcGIS Maps SDK for JavaScript in a Webpack application.

See the [Get started with npm guide](https://developers.arcgis.com/javascript/latest/get-started/#npm) for full instructions.
