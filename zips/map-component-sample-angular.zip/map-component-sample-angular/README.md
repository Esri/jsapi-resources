# Map components Angular sample

📁 **[Click here to download this directory as a ZIP file](https://esri.github.io/jsapi-resources/zips/map-component-sample-angular.zip)** 📁

## Known issues

- The [@arcgis/map-components-angular](https://www.npmjs.com/package/@arcgis/map-components-angular) npm package has been deprecated at 4.31. We recommend using the `@arcgis/map-components`, as shown in this sample.
- For versions prior to 4.32, the compile warning `The glob pattern import("./**/*.entry.js*") did not match any files [empty-glob]` is a known issue with Stencil and it can be ignored.
