# Charts components Vite sample (beta)

This project showcases how to integrate the charts components using vite.

## Get Started

Run `npm install` and then start adding modules.

For a list of all available `npm` commands see `scripts` in `package.json`, e.g. `npm run build`.
