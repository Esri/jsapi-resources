# Map components CDN sample

📁 **[Click here to download this directory as a ZIP file](https://github.com/Esri/jsapi-resources/blob/main/zips/map-component-sample-cdn.zip)** 📁
