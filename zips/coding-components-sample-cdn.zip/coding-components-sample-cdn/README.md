# Coding components CDN sample

📁 **[Click here to download this directory as a ZIP file](https://github.com/Esri/jsapi-resources/blob/main/zips/coding-components-sample-cdn.zip)** 📁

Since the ArcGIS Maps SDK for JavaScript and Calcite Components are dependencies of Coding Components they have to be loaded first. Coding Components will detect that it is used under AMD and will require its Maps SDK dependencies using the AMD module loader.
