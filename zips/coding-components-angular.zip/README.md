# Coding components Angular sample

📁 **[Click here to download this directory as a ZIP file](https://esri.github.io/jsapi-resources/zips/coding-components-angular.zip)** 📁

See the [Get started with npm guide](https://developers.arcgis.com/javascript/latest/get-started/#use-arcgiscreate) for full instructions and the [Coding components reference](https://developers.arcgis.com/javascript/latest/references/coding-components/) documentation for more information.

> [!TIP]
> **Angular 22** Angular 22 introduces a new chunk optimization strategy that may produce a substantially different build output than Angular 21. In testing with this sample application, Angular 22 generated fewer chunks, changed startup bundle composition, and produced different Lighthouse performance results.
>
> If you want a build output that more closely resembles Angular 21, add the following build script to your package.json:
>
> `"build-faster": "NG_BUILD_OPTIMIZE_CHUNKS=0 ng build --configuration production"`
>
> Performance characteristics vary by application. Be sure to benchmark your build times and runtime performance before and after enabling this workaround.

## Known issues

- You may encounter the following build configuration error:
  `[ERROR] No loader is configured for ".ttf" files: node_modules/monaco-editor/esm/vs/base/browser/ui/codicons/codicon/codicon.ttf`.
  - To fix this, the following has been added to the `angular.json` configuration file in this sample:

    ```json
    "loader": {
      ".ttf": "file"
    }
    ```

- `.woff2` asset file support should be enabled to support font importing.
  - To fix this, the following has been added to the `angular.json` configuration file in this sample:

    ```json
    "loader": {
      ".woff2": "file"
    }
    ```

  - See [this issue](https://github.com/angular/angular-cli/issues/31018) for more information.

- `../node_modules/monaco-editor/min/vs/editor/editor.main.css` is imported directly because the Monaco package export map does not expose this CSS file to Angular's production builder. This also works around an [Angular bug](https://github.com/angular/angular-cli/issues/31017) that prevents CSS auto-loading in the production build.

- You may encounter the following warning when running the sample:
  `The above dynamic import cannot be analyzed by Vite`.
  This does not affect the functionality of the sample. The problem may be related to Angular's Vite configuration and how it handles dynamic imports such as those in the [monaco-editor](https://microsoft.github.io/monaco-editor/) which the Arcade Editor component is built with.
  - https://github.com/angular/angular-cli/issues/29470
  - https://github.com/angular/angular/issues/59764
