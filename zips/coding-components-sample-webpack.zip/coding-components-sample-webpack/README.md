# Coding components Webpack sample

📁 **[Click here to download this directory as a ZIP file](https://github.com/Esri/jsapi-resources/blob/main/zips/coding-components-sample-webpack.zip)** 📁

This repository showcases how to integrate the coding components using webpack.

Run `npm install` and then start adding modules.

For a list of all available `npm` commands see `scripts` in `package.json`, e.g. `npm run build`.


