# Coding components Webpack sample

This repository showcases how to integrate the coding components using webpack.

Run `npm install` and then start adding modules.

For a list of all available `npm` commands see `scripts` in `package.json`, e.g. `npm run build`.


