# Charts components (beta) with Map components - (solution)
