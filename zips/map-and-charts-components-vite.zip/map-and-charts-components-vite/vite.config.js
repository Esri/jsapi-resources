import { defineConfig } from "vite";

export default defineConfig({
  plugins: [],
  server: {
    open: true,
  },
  build: {
    outDir: "dist",
  },
});
