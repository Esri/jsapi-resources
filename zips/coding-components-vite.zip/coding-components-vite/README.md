# Coding components Vite sample

📁 **[Click here to download this directory as a ZIP file](https://esri.github.io/jsapi-resources/zips/coding-components-vite.zip)** 📁

See the [Get started with npm guide](https://developers.arcgis.com/javascript/latest/get-started/#npm) for full instructions and the [Coding components reference](https://developers.arcgis.com/javascript/latest/references/coding-components/) documentation for more information.
