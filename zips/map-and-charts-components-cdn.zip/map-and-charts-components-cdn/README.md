# Components (Map and Charts) CDN sample

📁 **[Click here to download this directory as a ZIP file](https://esri.github.io/jsapi-resources/zips/map-and-charts-components-cdn.zip)** 📁

This sample demonstrates how to use the Map and Charts components from the ArcGIS Maps SDK for JavaScript via CDN.

See the [Get started with CDN guide](https://developers.arcgis.com/javascript/latest/web-components/get-started/#cdn) for full setup instructions.
