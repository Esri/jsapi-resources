<script setup>
import Chart from "@/components/Chart.vue";

// Individual imports for each component
import "@arcgis/charts-components/components/arcgis-chart";
import "@arcgis/charts-components/components/arcgis-charts-action-bar";
</script>

<template>
  <Chart />
</template>
