# Vue 3 + Vite

📁 **[Click here to download this directory as a ZIP file](https://esri.github.io/jsapi-resources/zips/coding-components-sample-vue.zip)** 📁

See the [Get started with npm guide](https://developers.arcgis.com/javascript/latest/get-started/#npm) for full instructions.
