// Import the `arcgis-map` component from the `@arcgis/map-components` package.
import "@arcgis/map-components/components/arcgis-map";

// Import the `arcgis-chart` and `arcgis-charts-action-bar` components from the `@arcgis/charts-components` package.
import "@arcgis/charts-components/components/arcgis-chart";
import "@arcgis/charts-components/components/arcgis-charts-action-bar";
